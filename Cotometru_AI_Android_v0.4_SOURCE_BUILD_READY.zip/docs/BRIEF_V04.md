# Brief implementare — Cotometru Android v0.4

## Obiectiv
O experiență de aplicație Android utilizabilă pe Google Play în viitor,
cu brandul oficial Cotometru AI și conținutul sincronizat de la cotometru.ro.

## Design
- Identitate C corai + fulger lime, fundal vinete închis, text luminos.
- Bară Android 56dp cu logo, nume, căutare, meniu.
- Taburi Android Oferte / Meciuri / Rezultate / Cont.
- Meniu deschis la butonul ☰: Știri, AI, favorite, comparare, instrumente.
- Evită două navigații suprapuse (ascunde header/footer/mobile-tab ale site-ului în WebView).
- Respectă zonele sistem Android, ecrane mici și text scaling.

## Comportament
- Navigare internă pentru paginile cotometru.ro, externă pentru alte domenii.
- Istoric Back și sesiune login persistente.
- Suport pentru `<input type=file>` fără permisiuni generale la galerie.
- Loading indicator + stare offline/retry de adăugat într-un release final.
- Fără noua instalare PHP/MySQL; site-ul curent continuă să servească datele.

## QA înainte de release
Testare reală pe Android 12–16, 360/390/430dp, portrait/landscape,
site/logout/alertes/AI import, strict WebView security, accesibilitate și analytics.
Validare politicilor Google Play pentru conținut gambling-related.

## Statut
Proiectul conține UI nativ + WebView. Nu include încă push notifications,
release signing, AAB ori aprobare Google Play.
