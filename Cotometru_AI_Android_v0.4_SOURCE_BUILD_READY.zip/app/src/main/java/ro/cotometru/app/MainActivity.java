package ro.cotometru.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Cotometru AI v0.4 — native Android navigation shell, existing secure site content.
 * No injected Javascript bridge; no location, camera or broad storage permission.
 * The app doesn't place bets or run native ads. Its website's privacy controls remain.
 */
public final class MainActivity extends Activity {
    private static final String ROOT = "https://cotometru.ro";
    private static final String OFFERS = ROOT + "/ro/";
    private static final String MATCHES = ROOT + "/ro/meciuri-azi";
    private static final String RESULTS = ROOT + "/ro/results";
    private static final String ACCOUNT = ROOT + "/index.php?p=member";
    private static final int PICK_IMAGE = 9004;
    private static final int BG = 0xFF171018;
    private static final int SURFACE = 0xFF261B28;
    private static final int ACCENT = 0xFFFA536D;
    private static final int LIME = 0xFFD9FA51;
    private static final int WHITE = 0xFFF7F3F6;

    private WebView browser;
    private ProgressBar progress;
    private TextView heading;
    private LinearLayout bottom;
    private ValueCallback<Uri[]> pendingFiles;
    private String currentSection = "Oferte";

    // Only removes redundant website chrome. The site itself remains fully maintained at cotometru.ro.
    private static final String APP_CSS = "(function(){" +
        "if(document.getElementById('cotometru-native-mode'))return;" +
        "var s=document.createElement('style');s.id='cotometru-native-mode';" +
        "s.textContent='.site-head,.mobile-tab,.site-foot{display:none!important}' +" +
        "'main.container{padding-top:12px!important;padding-bottom:26px!important}' +" +
        "'body{overflow-x:hidden!important}';document.head.appendChild(s);" +
        "})()";

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(13));
        if(stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(7), dp(10), dp(7));
        top.setBackgroundColor(BG);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(58)));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.cotometru_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(38), dp(38));
        logoParams.rightMargin = dp(10);
        top.addView(logo, logoParams);
        logo.setContentDescription("Cotometru AI");
        logo.setOnClickListener(v -> navigate(OFFERS, "Oferte"));

        heading = new TextView(this);
        heading.setText("COTOMETRU AI");
        heading.setTextColor(WHITE);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextSize(17);
        heading.setSingleLine(true);
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));

        TextView search = toolbarButton("⌕", "Caută oferte");
        search.setOnClickListener(v -> showSearch());
        top.addView(search, new LinearLayout.LayoutParams(dp(43), dp(43)));

        TextView menu = toolbarButton("☰", "Deschide meniul");
        menu.setOnClickListener(v -> showMenu(menu));
        top.addView(menu, new LinearLayout.LayoutParams(dp(43), dp(43)));

        View line = new View(this);
        line.setBackgroundColor(ACCENT);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(2)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setIndeterminate(false);
        if (Build.VERSION.SDK_INT >= 21) progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));
        progress.setVisibility(View.INVISIBLE);

        browser = new WebView(this);
        browser.setBackgroundColor(BG);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Needed for Android's scoped photo picker.
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        if (Build.VERSION.SDK_INT >= 21) settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, false);

        browser.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progress.setVisibility(View.VISIBLE);
                progress.setProgress(7);
            }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.INVISIBLE);
                if(isSiteUrl(url)) {
                    view.evaluateJavascript(APP_CSS, null);
                    if(url.contains("meciuri-azi")) selectTab("Meciuri");
                    else if(url.contains("/results")) selectTab("Rezultate");
                    else if(url.contains("p=member") || url.contains("p=login")) selectTab("Cont");
                    else if(url.equals(OFFERS) || url.contains("cote-marite")) selectTab("Oferte");
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if(isSiteUrl(request.getUrl().toString())) return false;
                external(request.getUrl());
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if(isSiteUrl(url)) return false;
                external(Uri.parse(url));
                return true;
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                if(value == 100) progress.setVisibility(View.INVISIBLE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = callback;
                try { startActivityForResult(params.createIntent(), PICK_IMAGE); return true; }
                catch (ActivityNotFoundException ex) {
                    pendingFiles = null;
                    Toast.makeText(MainActivity.this, "Nu există o aplicație pentru alegerea fișierului", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        browser.setDownloadListener((url, agent, disposition, type, length) -> {
            if(!url.startsWith("https://")) return;
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "cotometru-" + System.currentTimeMillis());
                if(isSiteUrl(url)) {
                    String cookie = CookieManager.getInstance().getCookie(url);
                    if(cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
                }
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                Toast.makeText(this, "Descărcarea a început", Toast.LENGTH_SHORT).show();
            } catch (Exception ex) { external(Uri.parse(url)); }
        });
        root.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));

        bottom = new LinearLayout(this);
        bottom.setBackgroundColor(BG);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(dp(4), dp(5), dp(4), dp(5));
        root.addView(bottom, new LinearLayout.LayoutParams(-1, dp(62)));
        addTab("⚡", "Oferte", OFFERS);
        addTab("◷", "Meciuri", MATCHES);
        addTab("↗", "Rezultate", RESULTS);
        addTab("♙", "Cont", ACCOUNT);
        selectTab("Oferte");

        if(savedState != null) {
            browser.restoreState(savedState);
            currentSection = savedState.getString("section", "Oferte");
            selectTab(currentSection);
        } else browser.loadUrl(OFFERS);
    }

    private TextView toolbarButton(String glyph, String description) {
        TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setText(glyph);
        t.setTextSize(27);
        t.setTextColor(WHITE);
        t.setContentDescription(description);
        t.setBackground(shape(SURFACE, 0));
        return t;
    }

    private void addTab(String symbol, String label, String url) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextSize(23);
        icon.setGravity(Gravity.CENTER);
        icon.setTextColor(WHITE);
        item.addView(icon, new LinearLayout.LayoutParams(-1, dp(31)));
        TextView title = new TextView(this);
        title.setText(label);
        title.setTextSize(11);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(WHITE);
        title.setSingleLine(true);
        item.addView(title, new LinearLayout.LayoutParams(-1, dp(19)));
        item.setTag(label);
        item.setContentDescription(label);
        item.setOnClickListener(v -> navigate(url, label));
        bottom.addView(item, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private void selectTab(String section) {
        currentSection = section;
        if(heading != null) heading.setText(section.equals("Oferte") ? "COTOMETRU AI" : section);
        for(int i = 0; i < bottom.getChildCount(); i++) {
            LinearLayout tab = (LinearLayout)bottom.getChildAt(i);
            boolean chosen = section.equals(tab.getTag());
            ((TextView)tab.getChildAt(0)).setTextColor(chosen ? LIME : WHITE);
            ((TextView)tab.getChildAt(1)).setTextColor(chosen ? LIME : 0xFFB9A9BB);
        }
    }

    private void navigate(String url, String section) {
        selectTab(section);
        if (browser != null && !url.equals(browser.getUrl())) browser.loadUrl(url);
    }

    private void showMenu(View anchor) {
        PopupMenu p = new PopupMenu(this, anchor);
        String[] titles = {"Oferte", "Meciuri azi", "Știri sportive", "De urmărit", "Salvate", "Compară", "Calculator", "Asistent AI", "Cont și alerte", "Administrare"};
        String[] urls = {OFFERS, MATCHES, ROOT+"/ro/stiri-sportive", ROOT+"/index.php?p=proposals", ROOT+"/ro/saved", ROOT+"/ro/comparator-oferte", ROOT+"/index.php?p=calculator", ROOT+"/index.php?p=ai", ACCOUNT, ROOT+"/index.php?p=admin"};
        for(int i=0; i<titles.length; i++) p.getMenu().add(0,i,i,titles[i]);
        p.setOnMenuItemClickListener(item -> {
            int idx=item.getItemId();
            if(idx<0||idx>=urls.length)return false;
            navigate(urls[idx],titles[idx]);
            return true;
        });
        p.show();
    }

    private void showSearch() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Echipă, meci sau jucător");
        int m = dp(16);
        LinearLayout container = new LinearLayout(this);
        container.setPadding(m,dp(4),m,0);
        container.addView(input,new LinearLayout.LayoutParams(-1,dp(56)));
        new AlertDialog.Builder(this).setTitle("Caută în Cotometru")
            .setView(container)
            .setNegativeButton("Anulează",(d,w)->{})
            .setPositiveButton("Caută",(d,w)-> navigate(OFFERS+"?q="+Uri.encode(input.getText().toString().trim()),"Oferte"))
            .show();
    }

    private boolean isSiteUrl(String address) {
        try {
            Uri u=Uri.parse(address);
            String host=u.getHost();
            return "https".equalsIgnoreCase(u.getScheme()) && host != null &&
                (host.equalsIgnoreCase("cotometru.ro") || host.equalsIgnoreCase("www.cotometru.ro"));
        } catch(Exception ex) { return false; }
    }
    private void external(Uri url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW,url)); }
        catch(Exception ex) { Toast.makeText(this,"Nu am putut deschide linkul extern",Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request==PICK_IMAGE && pendingFiles!=null) {
            Uri[] selected=WebChromeClient.FileChooserParams.parseResult(result,data);
            pendingFiles.onReceiveValue(result==RESULT_OK ? selected : null);
            pendingFiles=null;
        }
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        browser.saveState(state);
        state.putString("section",currentSection);
    }
    @Override public void onBackPressed() {
        if(browser!=null && browser.canGoBack()) browser.goBack();
        else new AlertDialog.Builder(this).setMessage("Închizi Cotometru AI?")
            .setNegativeButton("Rămân",(d,w)->{})
            .setPositiveButton("Ieșire",(d,w)-> finish()).show();
    }
    @Override protected void onDestroy() {
        if(pendingFiles!=null) { pendingFiles.onReceiveValue(null); pendingFiles=null; }
        if(browser!=null) browser.destroy();
        super.onDestroy();
    }
}
