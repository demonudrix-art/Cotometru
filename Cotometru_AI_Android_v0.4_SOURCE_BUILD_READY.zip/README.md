# Cotometru AI — Android v0.4 (sursă pentru Android Studio)

**Brand:** Cotometru AI · https://cotometru.ro · `ro.cotometru.app`.

**IMPORTANT:** acest ZIP este un **proiect Android**, nu un APK deja compilat. Nu include
chei API, parole, date personale sau chei de semnare. Nu este un release acceptat în Google Play.

## Ce este implementat în v0.4

- Icon oficial Cotometru — **C corai, fulger lime**, extras din `assets/logo.svg`
  al site-ului; folosit în launcher, bară de sus și ca icon adaptiv.
- Bara superioară **nativă**: logo, titlul secțiunii, căutare și buton `☰` pentru meniu.
- Meniu nativ cu Oferte, Meciuri, Știri sportive, De urmărit, Salvate, Compară,
  Calculator, AI, Cont și Administrare.
- Patru taburi native jos: Oferte / Meciuri / Rezultate / Cont.
- Elementele duplicate de navigare ale site-ului se ascund *numai în WebView-ul aplicației*;
  site-ul web rămâne neschimbat.
- WebView securizat `https://cotometru.ro` cu cookie-uri, JavaScript și storage
  necesare pentru conturi, filtre și AI.
- Selector nativ de fișiere pentru importul de capturi Betano/Superbet.
- Linkurile din afara cotometru.ro sunt deschise în browserul extern.
- DownloadManager, loading bar, buton Înapoi, căutare și tratarea reîncărcării ecranului.

### Limitări

Conținutul ofertelor, paginile și conturile sunt încă afișate prin WebView. Este o
**aplicație hibridă cu navigare nativă**, nu o rescriere 100% nativă. Nu există încă
notificări push native, autentificare biometrică sau integrare API mobil independent.
Logo-ul și meniurile native nu depind de CSS-ul serverului. Se cere conexiune la internet.

## Compilează APK prin Android Studio

1. Instalează **Android Studio** (versiune cu suport AGP 8.7.3 / Java 17).
2. File → Open → alege directorul dezarhivat `Cotometru_AI_Android_v0.4`.
3. Așteaptă sincronizarea Gradle și instalarea componentelor SDK.
4. Build → Build Bundle(s) / APK(s) → **Build APK(s)**.
5. Preia `app/build/outputs/apk/debug/app-debug.apk` și instalează-l pe telefon.

Dacă apare conflict de semnătură cu v0.3, dezinstalează v0.3 înainte. Nu se
șterg date de pe site; datele locale WebView pot necesita o nouă autentificare.

## Compilează APK online cu GitHub Actions

1. Creează un repo GitHub privat și încarcă **conținutul** directorului proiectului,
   inclusiv `.github/workflows/build-android.yml`.
2. Actions → **Cotometru Android APK** → Run workflow.
3. La final, intră în run → Artifacts → descarcă `Cotometru-AI-v0.4-debug-apk`.
4. În interior găsești `app-debug.apk`.

Acest flux folosește compilarea oficială Gradle + Android SDK pe un runner și
nu necesită SDK instalat pe calculatorul tău. GitHub poate impune reguli de
utilizare/cost pentru Actions. Nu publica chei în depozit.

## Pentru Google Play

Pentru publicare: se va produce un **AAB release semnat** cu o cheie persistentă;
se vor completa Privacy Policy, Data safety, rating, capturi, permisiuni și teste.
Actualizează compileSdk/targetSdk conform cerințelor Google Play în vigoare la publicare.
Revizuiește cu atenție politica Play pentru aplicații cu cote de pariuri,
reclame, promoții și linkuri către operatori. Publicarea nu este garantată.

## QA pe Android 16 (Samsung)

- Instalează și pornește aplicația; logo-ul trebuie să fie C+fulger.
- Headerul `Cotometru AI` cu `☰` și bara de jos trebuie să fie vizibile.
- Verifică meniul nativ, Oferte, Meciuri, Rezultate, Cont.
- Logare, căutare, favorite, comutare listă/card, comparator, filtrare.
- Import AI → adaugă imagine din Galerie/Fișiere.
- O sursă de știre externă se deschide în browserul sistemului.
- Pagina nu trebuie să prezinte două bare de navigație sau scroll orizontal.
- Testează refuz și accept cookie, buton Înapoi, rotire și lipsa conexiunii.

Nu am putut rula APK-ul pe un telefon/emulator în mediul de generare.
